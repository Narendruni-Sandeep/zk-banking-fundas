    function clear() {
        // Get a reference to the imp div
        var impDiv = document.querySelector('.imp');

        // Clear existing contents of the div
        while (impDiv.firstChild) {
            impDiv.removeChild(impDiv.firstChild);
        }

        // Create a new label element
      
    }